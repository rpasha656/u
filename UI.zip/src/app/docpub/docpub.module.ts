import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { DocpubComponent } from './index';
import { UploadComponent } from './upload.component';
import { FileListingComponent } from './filelisting.component';
import { FileMetadataService } from './filemetadata.service';
import { HttpModule } from '@angular/http';
import { ReactiveFormsModule } from '@angular/forms';
import { TableSortable } from './tableSortable';
import { NewcategoryComponent } from './newcategory.component';
import { CategoryEdit } from './categoryEdit.component';
import { PdfViewerComponent } from './pdf-viewer.component';
import { OrderBy } from './orderBy';
import { SearchPipe } from './search';
import { NdvEditComponent } from './ndvedit.component';
// import { NDV_DIRECTIVES } from 'angular2-click-to-edit/components';
@NgModule({
    declarations: [
        DocpubComponent,
        UploadComponent,
        FileListingComponent,
        TableSortable,
        OrderBy,
        SearchPipe,
        PdfViewerComponent,
        NewcategoryComponent,
        CategoryEdit,
        NdvEditComponent
    ],
    imports: [
        FormsModule,
        CommonModule,
        HttpModule,
        ReactiveFormsModule
    ],
    providers: [FileMetadataService],
    exports: [
        DocpubComponent,
        UploadComponent,
        FileListingComponent,
        CategoryEdit
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class DocpubModule {
}
