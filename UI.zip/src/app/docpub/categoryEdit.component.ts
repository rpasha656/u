import { Component } from '@angular/core';


@Component({
    selector: 'as-edit-category',
    template: require('./categoryEdit.component.html')
})
export class CategoryEdit {

    categoryData = [];
    newCategory: string;
    public subcategory: string;
    constructor() {
        console.log(this.categoryData);
        this.newCategory = '';
        this.subcategory = '';
    }

    editCategory(event, index) {
        console.log(event.target.outerText);
        this.categoryData[index] = event.target.outerText;
    }

    addCategory() {
        console.log(this.newCategory);
        if (this.newCategory.length > 0) {
            this.categoryData.push(this.newCategory);
            this.newCategory = '';
        }
    }
    loadsubcategory(categoryname: string) {
        this.subcategory = 'sub ' + categoryname;
    }

    onRowClick(event, id) {
        console.log(event.target.outerText, id);
    }
}
